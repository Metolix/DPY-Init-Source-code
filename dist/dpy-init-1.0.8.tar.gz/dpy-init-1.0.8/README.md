# dpy-init

dpy-init is a Python library which will instantly setup

## Installation

Use the package manager [pip](https://pypi.org/project/dpy-init/) to install dpy-init.

```bash
pip install dpy-init
```

## Usage

```bash
dpy-init
```

After typing in the command above, It will ask you which library you would like to use. After selecting a library, It will ask you which commands type you would like to use. After selecting that, Your `main.py` file is created!

## About the Author

The author, Me. Is a Python Developer and a Discord Bot creator. Reach out to me on discord [by clicking here](https://discord.com/users/807146991179399178)

Enjoy the library!